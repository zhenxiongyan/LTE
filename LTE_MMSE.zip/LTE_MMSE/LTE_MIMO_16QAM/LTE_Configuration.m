%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%          LTE configuration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
clear;
close all;
warning off;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%          system parameter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nt = 2;% # of tx antennas
FFTsize = 2048;% fftsize for 20Mhz
RBNum = 110;% 20M RB number
RENum = RBNum*12;% RE number
GuardSize = FFTsize - RENum;% guard size
LeftGuardSize = GuardSize/2;
RightGuardSize = LeftGuardSize - 1;
PilotIdxStream1 = [LeftGuardSize+2:6:FFTsize-RightGuardSize-1].';
PilotIdxStream2 = [LeftGuardSize+3:6:FFTsize-RightGuardSize].';
% data RE
dataSizePerStream = RENum - 2*length(PilotIdxStream1);
% CP size
CPSize = 144;% cp size
% data RE number
dataSizeTotal = dataSizePerStream*Nt;
% bit number
bitNum = dataSizeTotal*4;

